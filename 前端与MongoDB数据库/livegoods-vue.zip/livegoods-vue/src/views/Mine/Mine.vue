<template>
    <div>
        mine
        <FootNav />
    </div>
</template>
<script>
import FootNav from '../../components/FootNav/FootNav'
export default {
    name:'Mine',
    data(){
        return{}
    },
    components:{
        FootNav
    }
}
</script>