const base = {
    baseUrl:"/api",
    banner:'/banner',
    hotProduct:'/hotProduct',
    recommendation:"/recommendation",
    search:"/search",
    details:'/details',
    comment:"/comment",
    order:"/order",
    feelback:"/feelback",
    login:'/login',
    buytime:'/buytime',
    buyaction:"/buyaction",
    sendyzm:'/sendyzm'
}

export default base;