module.exports = {
    status:200,
    data: [
        {
            id: Math.random().toString().slice(2),
            title: "上海落地灯",
            img: "http://iwenwiki.com/api/livable/homehot/img_luodideng.png",
            link: "http://www.iwenwiki.com"
        },
        {
            id: Math.random().toString().slice(2),
            title: "上海置物架",
            img: "http://iwenwiki.com/api/livable/homehot/img_zhiwujia.png",
            link: "http://www.iwenwiki.com"
        },
        {
            id: Math.random().toString().slice(2),
            title: "上海矮脚灯",
            img: "http://iwenwiki.com/api/livable/homehot/img_aijiaodeng.png",
            link: "http://www.iwenwiki.com"
        },
        {
            id: Math.random().toString().slice(2),
            title: "上海毛巾",
            img: "http://iwenwiki.com/api/livable/homehot/img_maojin.png",
            link: "http://www.iwenwiki.com"
        }
    ]
}
